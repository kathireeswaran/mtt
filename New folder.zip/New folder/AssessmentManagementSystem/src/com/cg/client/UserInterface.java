package com.cg.client;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Trainee;

public class UserInterface {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager = entityManagerFactory.createEntityManager();
		manager.getTransaction().begin();
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the trainee name :");
		String traineeName = scanner.nextLine();
		System.out.println("enter the moduleName :");
		String moduleName = scanner.nextLine();
		System.out.println("enter the mptMark(out of 70):");
		int mptMarks = scanner.nextInt();
		System.out.println("enter the mttMark(out of 40):");
		int mttMarks = scanner.nextInt();
		int mttMark = (int) (mttMarks * 0.375);
		System.out.println("enter the assignmentMark(out of 100):");
		int assignmentMarks = scanner.nextInt();
		int assignmentMark = (int) (assignmentMarks * 0.15);
	
		int totalMarks = mptMarks + mttMark + assignmentMark;
		Trainee trainee = new Trainee();
		trainee.setTraineeName(traineeName);
		trainee.setModuleName(moduleName);
		trainee.setMptMarks(mptMarks);
		trainee.setMttMarks(mttMarks);
		trainee.setAssignmentMarks(assignmentMarks);
		trainee.setTotalMarks(totalMarks);
		manager.persist(trainee);
		manager.getTransaction().commit();
		manager.close();
		entityManagerFactory.close();
		scanner.close();
	}

}
