import { Component } from '@angular/core';
@Component({
  selector: 'my-component',
  templateUrl: './app.mobilecomponent.html',

})
export class MobileComponent  { 
mobileName:string="welcome to my app!!! ";
}