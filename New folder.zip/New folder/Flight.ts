interface Flight
{
flightId:number;
flightName:string;
flightCode:number;
noOfSeat:number;
flightType:string;
}
let flight:Flight={
flightId:1001,
flightName:'AIRASIA',
flightCode:23,
noOfSeat:100,
flightType:'boeing'
}
console.log(this.flight.flightId+""+
this.flight.flightName+""+
this.flight.flightCode+""+
this.flight.noOfSeat+""+
this.flight.flightType);